package com.generation.service;

import com.generation.model.Course;
import com.generation.model.EnrolledCourse;
import com.generation.model.Student;

import java.util.ArrayList;
import java.util.HashMap;

public class StudentService
{
    private final HashMap<String, Student> students = new HashMap<>();

    public void registerStudent( Student student )
    {
        //TODO Add new student to the students hashmap
        Student newStudent = new Student(student.getId(), student.getName(), student.getEmail(),student.getBirthDate());
        this.students.put(newStudent.getId(), newStudent);

    }


    public Student findStudent( String studentId )
    {
        //TODO Find the student from the Hashmap with the student id
        if(this.students.containsKey(studentId)){
            return this.students.get(studentId);
        }
        return null;
    }

    public void enrollToCourse( String studentId, Course course )
    {
        //TODO check if students hashmap contains the studentsId, if not enroll student to the course
        Student existStudent = this.students.get(studentId);
        existStudent.enrollToCourse(course);

    }

    public void showSummary()
    {
        //TODO Loop through students hashmap and print out students' details including the enrolled courses
        for ( String key : this.students.keySet() )
        {
            Student student = this.students.get( key );
            System.out.println( student );
           // Student students = this.students.get(student.getId());
            System.out.println( "Enrolled Courses:" );
           System.out.println(enrolledCourses(student));

        }
    }

    public HashMap<String, EnrolledCourse> enrolledCourses(Student student)
    {
        //TODO return a HashMap of all the enrolledCourses
        Student students = this.students.get(student.getId());
        return students.getEnrolledCourses();

    }

    public Course findEnrolledCourse( Student student, String courseId ) {
        //TODO return the course enrolled by the student from the course Id
        Student findStudent = this.students.get(student.getId());

        findStudent.getEnrolledCourses();


        return null;
    }

    public void gradeStudent(Student student, Course course, double grade) {
        student.gradeCourse(course.getCode(), grade);
    }



    public HashMap<String, EnrolledCourse> getPassedCourses(Student student) {
        return student.findPassedCourses();
    }
}
